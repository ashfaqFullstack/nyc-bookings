(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_13156754._.js",
  "static/chunks/src_components_property-map_tsx_1d7152f1._.js",
  "static/chunks/node_modules_leaflet_dist_leaflet_88e19fd3.css"
],
    source: "dynamic"
});
