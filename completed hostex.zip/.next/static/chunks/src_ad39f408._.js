(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([typeof document === "object" ? document.currentScript : undefined, {

"[project]/src/lib/auth-context.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "AuthProvider": (()=>AuthProvider),
    "useAuth": (()=>useAuth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function AuthProvider({ children }) {
    _s();
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(true);
    const [mounted, setMounted] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    console.log('AuthProvider: Component rendering, isLoading:', isLoading, 'user:', !!user, 'mounted:', mounted);
    // Handle client-side mounting
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            console.log('AuthProvider: Mounting on client side');
            setMounted(true);
        }
    }["AuthProvider.useEffect"], []);
    // Initialize auth state after mounting
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "AuthProvider.useEffect": ()=>{
            if (!mounted) {
                console.log('AuthProvider: Not mounted yet, skipping auth init');
                return;
            }
            console.log('AuthProvider: Starting auth initialization');
            const initAuth = {
                "AuthProvider.useEffect.initAuth": async ()=>{
                    console.log('AuthContext: initAuth called');
                    const token = localStorage.getItem('authToken');
                    console.log('AuthContext: token exists:', !!token);
                    if (token) {
                        try {
                            console.log('AuthContext: Making request to /api/auth/me');
                            const response = await fetch('/api/auth/me', {
                                headers: {
                                    'Authorization': `Bearer ${token}`
                                }
                            });
                            console.log('AuthContext: Response status:', response.status);
                            if (response.ok) {
                                const data = await response.json();
                                console.log('AuthContext: Successfully got user data:', !!data.user);
                                setUser(data.user);
                            } else {
                                if (response.status === 401) {
                                    console.log('AuthContext: Token invalid, removing');
                                    localStorage.removeItem('authToken');
                                } else {
                                    console.log('AuthContext: Non-401 error:', response.status);
                                }
                            }
                        } catch (error) {
                            console.error('AuthContext: Error verifying token:', error);
                        }
                    } else {
                        console.log('AuthContext: No token found');
                    }
                    console.log('AuthContext: Setting isLoading to false');
                    setIsLoading(false);
                }
            }["AuthProvider.useEffect.initAuth"];
            initAuth();
        }
    }["AuthProvider.useEffect"], [
        mounted
    ]);
    const login = async (email, password)=>{
        try {
            const response = await fetch('/api/auth/login', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    email,
                    password
                })
            });
            if (response.ok) {
                const data = await response.json();
                setUser(data.user);
                localStorage.setItem('authToken', data.token);
                return {
                    success: true
                };
            }
            const errorData = await response.json();
            console.error('Login error:', errorData.error);
            return {
                success: false,
                error: errorData.error || 'Invalid email or password'
            };
        } catch (error) {
            console.error('Login error:', error);
            return {
                success: false,
                error: 'An unexpected error occurred'
            };
        }
    };
    const signup = async (userData)=>{
        try {
            const response = await fetch('/api/auth/register', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(userData)
            });
            if (response.ok) {
                const data = await response.json();
                setUser(data.user);
                localStorage.setItem('authToken', data.token);
                return {
                    success: true
                };
            }
            const errorData = await response.json();
            console.error('Signup error:', errorData.error);
            return {
                success: false,
                error: errorData.error || 'Failed to create account'
            };
        } catch (error) {
            console.error('Signup error:', error);
            return {
                success: false,
                error: 'An unexpected error occurred'
            };
        }
    };
    const updateProfile = async (userData)=>{
        const token = localStorage.getItem('authToken');
        if (!token) {
            return {
                success: false,
                error: 'Not authenticated'
            };
        }
        try {
            const response = await fetch('/api/auth/profile', {
                method: 'PUT',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify(userData)
            });
            if (response.ok) {
                const data = await response.json();
                setUser(data.user);
                return {
                    success: true
                };
            }
            const errorData = await response.json();
            console.error('Update profile error:', errorData.error);
            return {
                success: false,
                error: errorData.error || 'Failed to update profile'
            };
        } catch (error) {
            console.error('Update profile error:', error);
            return {
                success: false,
                error: 'An unexpected error occurred'
            };
        }
    };
    const logout = ()=>{
        setUser(null);
        localStorage.removeItem('authToken');
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            isLoggedIn: !!user,
            isLoading,
            login,
            signup,
            updateProfile,
            logout
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/auth-context.tsx",
        lineNumber: 188,
        columnNumber: 5
    }, this);
}
_s(AuthProvider, "C195cYAOlB9IrbZR9Q3836kvzFs=");
_c = AuthProvider;
function useAuth() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
}
_s1(useAuth, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "AuthProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/lib/wishlist-context.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "WishlistProvider": (()=>WishlistProvider),
    "useWishlist": (()=>useWishlist)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-context.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
const WishlistContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function WishlistProvider({ children }) {
    _s();
    console.log('WishlistProvider: Component rendering');
    const [wishlist, setWishlist] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]);
    const [isLoading, setIsLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const { user, isLoggedIn, isLoading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    console.log('WishlistProvider: user:', !!user, 'isLoggedIn:', isLoggedIn, 'authLoading:', authLoading);
    // Get auth token from localStorage
    const getToken = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[getToken]": ()=>{
            if ("TURBOPACK compile-time truthy", 1) {
                return localStorage.getItem('authToken');
            }
            "TURBOPACK unreachable";
        }
    }["WishlistProvider.useCallback[getToken]"], []);
    // Fetch wishlist from API
    const fetchWishlist = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "WishlistProvider.useCallback[fetchWishlist]": async ()=>{
            console.log('WishlistContext: fetchWishlist called');
            const token = getToken();
            console.log('WishlistContext: token exists:', !!token, 'user exists:', !!user, 'authLoading:', authLoading);
            if (token && user) {
                try {
                    console.log('WishlistContext: Fetching wishlist from API');
                    const response = await fetch('/api/wishlist', {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    });
                    if (response.ok) {
                        const data = await response.json();
                        console.log('WishlistContext: Fetched wishlist data:', data);
                        // Extract propertyId values from the array of objects
                        const propertyIds = (data.wishlist || []).map({
                            "WishlistProvider.useCallback[fetchWishlist].propertyIds": (item)=>item.propertyId
                        }["WishlistProvider.useCallback[fetchWishlist].propertyIds"]);
                        console.log('WishlistContext: Extracted property IDs:', propertyIds);
                        setWishlist(propertyIds);
                    } else {
                        console.error('WishlistContext: Failed to fetch wishlist:', response.status);
                    }
                } catch (error) {
                    console.error('WishlistContext: Error fetching wishlist:', error);
                }
            }
        }
    }["WishlistProvider.useCallback[fetchWishlist]"], [
        user,
        authLoading,
        getToken
    ]);
    console.log('WishlistProvider: About to set up useEffects');
    // Load wishlist when auth state changes
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "WishlistProvider.useEffect": ()=>{
            console.log('WishlistContext: Auth state useEffect triggered, user:', !!user, 'authLoading:', authLoading);
            // Only fetch if auth is not loading
            if (!authLoading) {
                if (user) {
                    console.log('WishlistContext: User authenticated, fetching wishlist');
                    fetchWishlist();
                } else {
                    console.log('WishlistContext: User not authenticated, clearing wishlist');
                    setWishlist([]);
                }
            }
        }
    }["WishlistProvider.useEffect"], [
        user,
        authLoading,
        fetchWishlist
    ]);
    const addToWishlist = async (propertyId)=>{
        console.log('WishlistContext: addToWishlist called for property:', propertyId);
        const token = getToken();
        console.log('WishlistContext: token exists:', !!token, 'user exists:', !!user);
        if (!token || !user) {
            console.log('WishlistContext: No token or user');
            return false;
        }
        try {
            console.log('WishlistContext: Sending POST request to /api/wishlist');
            const response = await fetch('/api/wishlist', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                },
                body: JSON.stringify({
                    propertyId
                })
            });
            console.log('WishlistContext: Response status:', response.status);
            if (response.ok) {
                console.log('WishlistContext: Successfully added to wishlist, updating local state');
                // Optimistically update the UI first
                setWishlist((prev)=>[
                        ...prev,
                        propertyId
                    ]);
                console.log('WishlistContext: Added to wishlist state');
                return true;
            }
            if (response.status === 409) {
                // Property already in wishlist - considered a success
                console.log('WishlistContext: Property already in wishlist (409)');
                return true;
            }
            const errorData = await response.json();
            console.error('WishlistContext: Add to wishlist error:', errorData.error);
            return false;
        } catch (error) {
            console.error('WishlistContext: Add to wishlist error:', error);
            return false;
        }
    };
    const removeFromWishlist = async (propertyId)=>{
        console.log('WishlistContext: removeFromWishlist called for property:', propertyId);
        const token = getToken();
        console.log('WishlistContext: token exists:', !!token, 'user exists:', !!user);
        if (!token || !user) {
            console.log('WishlistContext: No token or user');
            return false;
        }
        try {
            console.log('WishlistContext: Sending DELETE request to /api/wishlist');
            const response = await fetch(`/api/wishlist?propertyId=${encodeURIComponent(propertyId)}`, {
                method: 'DELETE',
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            console.log('WishlistContext: Response status:', response.status);
            if (response.ok) {
                console.log('WishlistContext: Successfully removed from wishlist, updating local state');
                // Optimistically update the UI
                setWishlist((prev)=>prev.filter((id)=>id !== propertyId));
                console.log('WishlistContext: Removed from wishlist state');
                return true;
            }
            const errorData = await response.json();
            console.error('WishlistContext: Remove from wishlist error:', errorData.error);
            return false;
        } catch (error) {
            console.error('WishlistContext: Remove from wishlist error:', error);
            return false;
        }
    };
    const isInWishlist = (propertyId)=>{
        const isIncluded = wishlist.includes(propertyId);
        console.log(`WishlistContext: isInWishlist(${propertyId}) = ${isIncluded}, current wishlist:`, wishlist);
        return isIncluded;
    };
    const refreshWishlist = async ()=>{
        await fetchWishlist();
    };
    // Create stable context value to avoid unnecessary re-renders
    const contextValue = {
        wishlist,
        isLoading,
        addToWishlist,
        removeFromWishlist,
        isInWishlist,
        refreshWishlist
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(WishlistContext.Provider, {
        value: contextValue,
        children: children
    }, void 0, false, {
        fileName: "[project]/src/lib/wishlist-context.tsx",
        lineNumber: 182,
        columnNumber: 5
    }, this);
}
_s(WishlistProvider, "RqTLCN3H/cNPMxDJ6Ox85DOmvSs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"]
    ];
});
_c = WishlistProvider;
function useWishlist() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(WishlistContext);
    if (context === undefined) {
        throw new Error('useWishlist must be used within a WishlistProvider');
    }
    return context;
}
_s1(useWishlist, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "WishlistProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/ClientBody.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname, k: __turbopack_refresh__, m: module } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>ClientBody)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$module__evaluation$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-client] (ecmascript) <module evaluation>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/same-runtime/dist/jsx-dev-runtime.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-context.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$wishlist$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/wishlist-context.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ClientBody({ children }) {
    _s();
    // Remove any extension-added classes during hydration
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ClientBody.useEffect": ()=>{
            // This runs only on the client after hydration
            document.body.className = "antialiased";
        }
    }["ClientBody.useEffect"], []);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["AuthProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$wishlist$2d$context$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["WishlistProvider"], {
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$same$2d$runtime$2f$dist$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["jsxDEV"])("div", {
                className: "antialiased",
                children: children
            }, void 0, false, {
                fileName: "[project]/src/app/ClientBody.tsx",
                lineNumber: 20,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/src/app/ClientBody.tsx",
            lineNumber: 19,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/ClientBody.tsx",
        lineNumber: 18,
        columnNumber: 5
    }, this);
}
_s(ClientBody, "OD7bBpZva5O2jO+Puf00hKivP7c=");
_c = ClientBody;
var _c;
__turbopack_context__.k.register(_c, "ClientBody");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
}]);

//# sourceMappingURL=src_ad39f408._.js.map