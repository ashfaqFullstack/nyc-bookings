(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_d174bdf2._.js",
  "static/chunks/src_components_admin_editable-map_tsx_eef1b714._.js",
  "static/chunks/node_modules_leaflet_dist_leaflet_88e19fd3.css"
],
    source: "dynamic"
});
