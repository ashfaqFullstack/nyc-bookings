(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_c430db0e._.js",
  "static/chunks/node_modules_04a37d57._.js",
  "static/chunks/src_styles_hostex-widget_f62288a9.css"
],
    source: "dynamic"
});
