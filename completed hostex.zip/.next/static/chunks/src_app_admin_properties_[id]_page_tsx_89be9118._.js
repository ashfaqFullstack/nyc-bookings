(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_cb3d84d8._.js",
  "static/chunks/node_modules_3a2d2b8b._.js",
  "static/chunks/node_modules_leaflet_dist_leaflet_88e19fd3.css"
],
    source: "dynamic"
});
