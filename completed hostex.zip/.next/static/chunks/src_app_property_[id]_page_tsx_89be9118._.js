(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_74d3f5d6._.js",
  "static/chunks/node_modules_next_6608d3cf._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_b854acb4._.js",
  "static/chunks/node_modules_leaflet_dist_leaflet-src_e7e140e9.js",
  "static/chunks/node_modules_cade8c0d._.js",
  "static/chunks/_5f9fa2d7._.css"
],
    source: "dynamic"
});
