(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_f7c0e5a6._.js",
  "static/chunks/node_modules_a3c2495c._.js",
  "static/chunks/src_styles_hostex-widget_f62288a9.css"
],
    source: "dynamic"
});
