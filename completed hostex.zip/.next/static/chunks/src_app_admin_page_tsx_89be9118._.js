(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_a38c84ca._.js",
  "static/chunks/src_ba871f33._.js"
],
    source: "dynamic"
});
