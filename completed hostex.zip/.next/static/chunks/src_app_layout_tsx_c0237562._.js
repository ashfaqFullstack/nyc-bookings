(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__8ebb6d4b._.css",
  "static/chunks/node_modules_0833f5a9._.js",
  "static/chunks/src_ad39f408._.js"
],
    source: "dynamic"
});
