(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_ca250cc4._.js",
  "static/chunks/node_modules_4e9b1cac._.js"
],
    source: "dynamic"
});
