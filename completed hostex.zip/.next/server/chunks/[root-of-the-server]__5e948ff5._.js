module.exports = {

"[project]/.next-internal/server/app/api/admin/properties/[id]/reviews/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/lib/db.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "sql": (()=>sql)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$neondatabase$2f$serverless$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@neondatabase/serverless/index.mjs [app-route] (ecmascript)");
;
if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL is not defined');
}
const sql = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$neondatabase$2f$serverless$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["neon"])(process.env.DATABASE_URL);
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[project]/src/lib/auth-utils.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "generateResetToken": (()=>generateResetToken),
    "generateResetTokenExpiry": (()=>generateResetTokenExpiry),
    "generateToken": (()=>generateToken),
    "getUserFromRequest": (()=>getUserFromRequest),
    "hashPassword": (()=>hashPassword),
    "isResetTokenValid": (()=>isResetTokenValid),
    "verifyPassword": (()=>verifyPassword),
    "verifyToken": (()=>verifyToken)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jsonwebtoken/index.js [app-route] (ecmascript)");
;
;
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-key';
if (!process.env.JWT_SECRET) {
    console.warn('JWT_SECRET environment variable is not set, using fallback');
}
async function hashPassword(password) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].hash(password, 12);
}
async function verifyPassword(password, hashedPassword) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].compare(password, hashedPassword);
}
function generateToken(user) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].sign({
        userId: user.id,
        email: user.email,
        role: user.role
    }, JWT_SECRET, {
        expiresIn: '7d'
    });
}
function verifyToken(token) {
    try {
        const decoded = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].verify(token, JWT_SECRET);
        return {
            userId: decoded.userId,
            email: decoded.email,
            role: decoded.role
        };
    } catch (error) {
        console.error('JWT verification failed:', error);
        return null;
    }
}
function getUserFromRequest(req) {
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return null;
    }
    const token = authHeader.substring(7);
    return verifyToken(token);
}
function generateResetToken() {
    // Generate a secure random token
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let token = '';
    for(let i = 0; i < 32; i++){
        token += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return token;
}
function generateResetTokenExpiry() {
    // Token expires in 1 hour
    const expiry = new Date();
    expiry.setHours(expiry.getHours() + 1);
    return expiry;
}
function isResetTokenValid(expiry) {
    if (!expiry) return false;
    return new Date() < new Date(expiry);
}
}}),
"[project]/src/lib/admin-middleware.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createAdminResponse": (()=>createAdminResponse),
    "verifyAdminToken": (()=>verifyAdminToken)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$utils$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-utils.ts [app-route] (ecmascript)");
;
;
async function verifyAdminToken(request) {
    try {
        const authHeader = request.headers.get('authorization');
        if (!authHeader?.startsWith('Bearer ')) {
            return {
                status: 401,
                error: 'No token provided'
            };
        }
        const token = authHeader.substring(7);
        const decoded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$utils$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyToken"])(token);
        if (!decoded) {
            return {
                status: 401,
                error: 'Invalid token'
            };
        }
        if (decoded.role !== 'admin') {
            return {
                status: 403,
                error: 'Admin access required'
            };
        }
        return {
            status: 200,
            user: decoded
        };
    } catch (error) {
        console.error('Token verification error:', error);
        return {
            status: 401,
            error: 'Invalid token'
        };
    }
}
function createAdminResponse(message, status, data) {
    const response = {
        message
    };
    if (data) {
        response.data = data;
    }
    if (status >= 400) {
        response.error = message;
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(response, {
        status
    });
}
}}),
"[project]/src/app/api/admin/properties/[id]/reviews/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DELETE": (()=>DELETE),
    "POST": (()=>POST),
    "PUT": (()=>PUT)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/admin-middleware.ts [app-route] (ecmascript)");
;
;
async function POST(request, { params }) {
    const authResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyAdminToken"])(request);
    if (authResult.status !== 200) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])(authResult.error || 'Authentication failed', authResult.status);
    }
    try {
        const { id } = await params;
        const propertyId = id;
        const { user, userImage, rating, date, comment } = await request.json();
        if (!user || !rating || !date || !comment) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Missing required fields', 400);
        }
        const newReview = {
            id: `review_${Date.now()}`,
            user,
            userImage: userImage || '',
            rating,
            date,
            comment
        };
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`
      UPDATE properties
      SET reviews = reviews || ${JSON.stringify(newReview)}::jsonb
      WHERE id = ${propertyId}
      RETURNING reviews;
    `;
        if (result.length === 0) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property not found', 404);
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Review added successfully', 201, {
            reviews: result[0].reviews
        });
    } catch (error) {
        console.error('Error adding review:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Failed to add review', 500);
    }
}
async function PUT(request, { params }) {
    const authResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyAdminToken"])(request);
    if (authResult.status !== 200) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])(authResult.error || 'Authentication failed', authResult.status);
    }
    try {
        const propertyId = params.id;
        const { id: reviewId, user, userImage, rating, date, comment } = await request.json();
        if (!reviewId || !user || !rating || !date || !comment) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Missing required fields', 400);
        }
        const propertyResult = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`SELECT reviews FROM properties WHERE id = ${propertyId}`;
        if (propertyResult.length === 0) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property not found', 404);
        }
        const reviews = propertyResult[0].reviews;
        const reviewIndex = reviews.findIndex((r)=>r.id === reviewId);
        if (reviewIndex === -1) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Review not found', 404);
        }
        reviews[reviewIndex] = {
            id: reviewId,
            user,
            userImage,
            rating,
            date,
            comment
        };
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`
      UPDATE properties
      SET reviews = ${JSON.stringify(reviews)}::jsonb
      WHERE id = ${propertyId}
      RETURNING reviews;
    `;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Review updated successfully', 200, {
            reviews: result[0].reviews
        });
    } catch (error) {
        console.error('Error updating review:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Failed to update review', 500);
    }
}
async function DELETE(request, { params }) {
    const authResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyAdminToken"])(request);
    if (authResult.status !== 200) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])(authResult.error || 'Authentication failed', authResult.status);
    }
    try {
        const propertyId = params.id;
        const { id: reviewId } = await request.json();
        if (!reviewId) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Review ID is required', 400);
        }
        const propertyResult = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`SELECT reviews FROM properties WHERE id = ${propertyId}`;
        if (propertyResult.length === 0) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property not found', 404);
        }
        const reviews = propertyResult[0].reviews;
        const updatedReviews = reviews.filter((r)=>r.id !== reviewId);
        if (reviews.length === updatedReviews.length) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Review not found', 404);
        }
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`
      UPDATE properties
      SET reviews = ${JSON.stringify(updatedReviews)}::jsonb
      WHERE id = ${propertyId}
      RETURNING reviews;
    `;
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Review deleted successfully', 200, {
            reviews: result[0].reviews
        });
    } catch (error) {
        console.error('Error deleting review:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Failed to delete review', 500);
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__5e948ff5._.js.map