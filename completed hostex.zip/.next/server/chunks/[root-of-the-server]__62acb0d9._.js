module.exports = {

"[project]/.next-internal/server/app/api/admin/properties/route/actions.js [app-rsc] (server actions loader, ecmascript)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
}}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}}),
"[project]/src/lib/db.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "sql": (()=>sql)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$neondatabase$2f$serverless$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@neondatabase/serverless/index.mjs [app-route] (ecmascript)");
;
if (!process.env.DATABASE_URL) {
    throw new Error('DATABASE_URL is not defined');
}
const sql = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$neondatabase$2f$serverless$2f$index$2e$mjs__$5b$app$2d$route$5d$__$28$ecmascript$29$__["neon"])(process.env.DATABASE_URL);
}}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/buffer [external] (buffer, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("buffer", () => require("buffer"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[project]/src/lib/auth-utils.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "generateResetToken": (()=>generateResetToken),
    "generateResetTokenExpiry": (()=>generateResetTokenExpiry),
    "generateToken": (()=>generateToken),
    "getUserFromRequest": (()=>getUserFromRequest),
    "hashPassword": (()=>hashPassword),
    "isResetTokenValid": (()=>isResetTokenValid),
    "verifyPassword": (()=>verifyPassword),
    "verifyToken": (()=>verifyToken)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/bcryptjs/index.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/jsonwebtoken/index.js [app-route] (ecmascript)");
;
;
const JWT_SECRET = process.env.JWT_SECRET || 'fallback-secret-key';
if (!process.env.JWT_SECRET) {
    console.warn('JWT_SECRET environment variable is not set, using fallback');
}
async function hashPassword(password) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].hash(password, 12);
}
async function verifyPassword(password, hashedPassword) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$bcryptjs$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].compare(password, hashedPassword);
}
function generateToken(user) {
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].sign({
        userId: user.id,
        email: user.email,
        role: user.role
    }, JWT_SECRET, {
        expiresIn: '7d'
    });
}
function verifyToken(token) {
    try {
        const decoded = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$jsonwebtoken$2f$index$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].verify(token, JWT_SECRET);
        return {
            userId: decoded.userId,
            email: decoded.email,
            role: decoded.role
        };
    } catch (error) {
        console.error('JWT verification failed:', error);
        return null;
    }
}
function getUserFromRequest(req) {
    const authHeader = req.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
        return null;
    }
    const token = authHeader.substring(7);
    return verifyToken(token);
}
function generateResetToken() {
    // Generate a secure random token
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let token = '';
    for(let i = 0; i < 32; i++){
        token += characters.charAt(Math.floor(Math.random() * characters.length));
    }
    return token;
}
function generateResetTokenExpiry() {
    // Token expires in 1 hour
    const expiry = new Date();
    expiry.setHours(expiry.getHours() + 1);
    return expiry;
}
function isResetTokenValid(expiry) {
    if (!expiry) return false;
    return new Date() < new Date(expiry);
}
}}),
"[project]/src/lib/admin-middleware.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "createAdminResponse": (()=>createAdminResponse),
    "verifyAdminToken": (()=>verifyAdminToken)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$utils$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/auth-utils.ts [app-route] (ecmascript)");
;
;
async function verifyAdminToken(request) {
    try {
        const authHeader = request.headers.get('authorization');
        if (!authHeader?.startsWith('Bearer ')) {
            return {
                status: 401,
                error: 'No token provided'
            };
        }
        const token = authHeader.substring(7);
        const decoded = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$auth$2d$utils$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyToken"])(token);
        if (!decoded) {
            return {
                status: 401,
                error: 'Invalid token'
            };
        }
        if (decoded.role !== 'admin') {
            return {
                status: 403,
                error: 'Admin access required'
            };
        }
        return {
            status: 200,
            user: decoded
        };
    } catch (error) {
        console.error('Token verification error:', error);
        return {
            status: 401,
            error: 'Invalid token'
        };
    }
}
function createAdminResponse(message, status, data) {
    const response = {
        message
    };
    if (data) {
        response.data = data;
    }
    if (status >= 400) {
        response.error = message;
    }
    return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(response, {
        status
    });
}
}}),
"[project]/src/app/api/admin/properties/route.ts [app-route] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "DELETE": (()=>DELETE),
    "GET": (()=>GET),
    "POST": (()=>POST)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/db.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/admin-middleware.ts [app-route] (ecmascript)");
;
;
async function GET(request) {
    const authResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyAdminToken"])(request);
    if (authResult.status !== 200) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])(authResult.error || 'Authentication failed', authResult.status);
    }
    try {
        const { searchParams } = new URL(request.url);
        const page = Number.parseInt(searchParams.get('page') || '1');
        const limit = Number.parseInt(searchParams.get('limit') || '20');
        const search = searchParams.get('search') || '';
        const offset = (page - 1) * limit;
        let whereClause = '';
        if (search) {
            whereClause = `WHERE title ILIKE '%${search}%' OR location ILIKE '%${search}%'`;
        }
        const properties = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`
      SELECT * FROM properties
      ${whereClause ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"].unsafe(whereClause) : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]``}
      ORDER BY createdat DESC
      LIMIT ${limit} OFFSET ${offset}
    `;
        // Transform properties to match the expected frontend format
        const transformedProperties = properties.map((property)=>({
                ...property,
                coordinates: typeof property.coordinates === 'string' ? JSON.parse(property.coordinates) : property.coordinates,
                neighborhoodInfo: typeof property.neighborhoodinfo === 'string' ? JSON.parse(property.neighborhoodinfo) : property.neighborhoodinfo,
                reviewCount: property.reviewcount,
                hostImage: property.hostimage,
                hostJoinedDate: property.hostjoineddate,
                checkIn: property.checkin,
                checkOut: property.checkout,
                houseRules: property.houserules,
                listing_id: property.listing_id,
                hostexwidgetid: property.hostexwidgetid,
                scriptsrc: property.scriptsrc,
                cancellationPolicy: property.cancellationpolicy
            }));
        const totalResult = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`
      SELECT COUNT(*) as total FROM properties
      ${whereClause ? __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"].unsafe(whereClause) : __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]``}
    `;
        const total = Number.parseInt(totalResult[0].total);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Properties fetched successfully', 200, {
            properties: transformedProperties,
            pagination: {
                page,
                limit,
                total,
                totalPages: Math.ceil(total / limit)
            }
        });
    } catch (error) {
        console.error('Error fetching properties:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Failed to fetch properties', 500);
    }
}
async function POST(request) {
    const authResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyAdminToken"])(request);
    if (authResult.status !== 200) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])(authResult.error || 'Authentication failed', authResult.status);
    }
    try {
        const body = await request.json();
        const { title, location, address, neighborhood, price, rating = 0, reviewCount = 0, images, host, hostImage, hostJoinedDate, amenities, description, bedrooms, bathrooms, beds, guests, checkIn, checkOut, houseRules, cancellationPolicy, coordinates, neighborhoodInfo, reviews, hostexwidgetid, scriptsrc, listing_id } = body;
        const id = body.id || `prop_${Date.now()}`;
        // Validation
        if (!title || !location || !neighborhood || !price || !images || !host || !description || !bedrooms || !bathrooms || !beds || !guests || !checkIn || !checkOut || !coordinates || !neighborhoodInfo) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Missing required fields', 400);
        }
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`
      INSERT INTO properties (
        id, title, location, address, neighborhood, price, rating, reviewcount,
        images, host, hostimage, hostjoineddate, amenities, description,
        bedrooms, bathrooms, beds, guests, checkin, checkout, houserules,
        cancellationpolicy, coordinates, neighborhoodinfo, reviews, hostexwidgetid, scriptsrc, listing_id,createdat
      ) VALUES (
        ${id}, ${title}, ${location}, ${address}, ${neighborhood}, ${price}, ${rating}, ${reviewCount},
        ${images}, ${host}, ${hostImage || ''}, ${hostJoinedDate || new Date().getFullYear().toString()},
        ${amenities}, ${description}, ${bedrooms}, ${bathrooms}, ${beds}, ${guests},
        ${checkIn}, ${checkOut}, ${houseRules || []}, ${cancellationPolicy || ''},
        ${JSON.stringify(coordinates)}, ${JSON.stringify(neighborhoodInfo)}, ${JSON.stringify(reviews)},
        ${hostexwidgetid}, ${scriptsrc}, ${listing_id},
        NOW()
      )
      RETURNING *
    `;
        // Transform the response to match frontend expectations
        const property = {
            ...result[0],
            coordinates: typeof result[0].coordinates === 'string' ? JSON.parse(result[0].coordinates) : result[0].coordinates,
            neighborhoodInfo: typeof result[0].neighborhoodinfo === 'string' ? JSON.parse(result[0].neighborhoodinfo) : result[0].neighborhoodinfo,
            reviewCount: result[0].reviewcount,
            hostImage: result[0].hostimage,
            listing_id: result[0].listing_id,
            hostJoinedDate: result[0].hostjoineddate,
            checkIn: result[0].checkin,
            checkOut: result[0].checkout,
            houseRules: result[0].houserules,
            hostexwidgetid: result[0].hostexwidgetid,
            scriptsrc: result[0].scriptsrc,
            cancellationPolicy: result[0].cancellationpolicy
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property created successfully', 201, {
            property
        });
    } catch (error) {
        console.error('Error creating property:', error);
        if (error instanceof Error && error.message?.includes('duplicate key')) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property ID already exists', 409);
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Failed to create property', 500);
    }
}
async function DELETE(request) {
    const authResult = await (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["verifyAdminToken"])(request);
    if (authResult.status !== 200) {
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])(authResult.error || 'Authentication failed', authResult.status);
    }
    try {
        const { searchParams } = new URL(request.url);
        const id = searchParams.get('id');
        if (!id) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property ID is required', 400);
        }
        const result = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["sql"]`
      DELETE FROM properties WHERE id = ${id}
      RETURNING id
    `;
        if (result.length === 0) {
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property not found', 404);
        }
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Property deleted successfully', 200);
    } catch (error) {
        console.error('Error deleting property:', error);
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$admin$2d$middleware$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["createAdminResponse"])('Failed to delete property', 500);
    }
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__62acb0d9._.js.map