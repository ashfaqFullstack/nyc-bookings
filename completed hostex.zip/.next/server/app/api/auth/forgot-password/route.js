const CHUNK_PUBLIC_PATH = "server/app/api/auth/forgot-password/route.js";
const runtime = require("../../../../chunks/[turbopack]_runtime.js");
runtime.loadChunk("server/chunks/node_modules_@react-email_render_dist_node_index_mjs_1c7616ad._.js");
runtime.loadChunk("server/chunks/node_modules_f3c22279._.js");
runtime.loadChunk("server/chunks/[root-of-the-server]__bce6acb8._.js");
runtime.getOrInstantiateRuntimeModule("[project]/.next-internal/server/app/api/auth/forgot-password/route/actions.js [app-rsc] (server actions loader, ecmascript)", CHUNK_PUBLIC_PATH);
runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/forgot-password/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH);
module.exports = runtime.getOrInstantiateRuntimeModule("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/auth/forgot-password/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)", CHUNK_PUBLIC_PATH).exports;
