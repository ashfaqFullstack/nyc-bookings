(()=>{var e={};e.id=665,e.ids=[665],e.modules={3295:e=>{"use strict";e.exports=require("next/dist/server/app-render/after-task-async-storage.external.js")},5069:(e,r,t)=>{"use strict";t.d(r,{l:()=>n});var o=t(88909);if(!process.env.DATABASE_URL)throw Error("DATABASE_URL is not defined");let n=(0,o.lw)(process.env.DATABASE_URL)},10846:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-page.runtime.prod.js")},23633:(e,r,t)=>{"use strict";t.d(r,{H:()=>i,U:()=>s});var o=t(32190),n=t(42317);async function s(e){try{let r=e.headers.get("authorization");if(!r?.startsWith("Bearer "))return{status:401,error:"No token provided"};let t=r.substring(7),o=(0,n.nr)(t);if(!o)return{status:401,error:"Invalid token"};if("admin"!==o.role)return{status:403,error:"Admin access required"};return{status:200,user:o}}catch(e){return console.error("Token verification error:",e),{status:401,error:"Invalid token"}}}function i(e,r,t){let n={message:e};return t&&(n.data=t),r>=400&&(n.error=e),o.NextResponse.json(n,{status:r})}},27910:e=>{"use strict";e.exports=require("stream")},27989:(e,r,t)=>{"use strict";t.r(r),t.d(r,{patchFetch:()=>g,routeModule:()=>d,serverHooks:()=>f,workAsyncStorage:()=>l,workUnitAsyncStorage:()=>h});var o={};t.r(o),t.d(o,{GET:()=>c,PUT:()=>p});var n=t(96559),s=t(48088),i=t(37719),a=t(5069),u=t(23633);async function c(e,{params:r}){let t=await (0,u.U)(e);if(200!==t.status)return(0,u.H)(t.error,t.status);try{let{id:e}=await r,t=await (0,a.l)`
      SELECT * FROM properties WHERE id = ${e}
    `;if(0===t.length)return(0,u.H)("Property not found",404);let o=t[0],n={...o,coordinates:"string"==typeof o.coordinates?JSON.parse(o.coordinates):o.coordinates,neighborhoodInfo:"string"==typeof o.neighborhoodinfo?JSON.parse(o.neighborhoodinfo):o.neighborhoodinfo,reviewCount:o.reviewcount,hostImage:o.hostimage,hostJoinedDate:o.hostjoineddate,checkIn:o.checkin,checkOut:o.checkout,houseRules:o.houserules,cancellationPolicy:o.cancellationpolicy};return(0,u.H)("Property fetched successfully",200,{property:n})}catch(e){return console.error("Error fetching property:",e),(0,u.H)("Failed to fetch property",500)}}async function p(e,{params:r}){let t=await (0,u.U)(e);if(200!==t.status)return(0,u.H)(t.error,t.status);try{let{id:t}=await r,{title:o,location:n,neighborhood:s,price:i,rating:c,reviewCount:p,images:d,host:l,hostImage:h,hostJoinedDate:f,amenities:g,description:y,bedrooms:m,bathrooms:v,beds:E,guests:x,checkIn:$,checkOut:w,houseRules:k,cancellationPolicy:b,coordinates:A,neighborhoodInfo:T}=await e.json();return await (0,a.l)`
      UPDATE properties
      SET
        title = ${o},
        location = ${n},
        neighborhood = ${s},
        price = ${i},
        rating = ${c},
        reviewcount = ${p},
        images = ${d},
        host = ${l},
        hostimage = ${h},
        hostjoineddate = ${f},
        amenities = ${g},
        description = ${y},
        bedrooms = ${m},
        bathrooms = ${v},
        beds = ${E},
        guests = ${x},
        checkin = ${$},
        checkout = ${w},
        houserules = ${k},
        cancellationpolicy = ${b},
        coordinates = ${JSON.stringify(A)},
        neighborhoodinfo = ${JSON.stringify(T)}
      WHERE id = ${t}
    `,(0,u.H)("Property updated successfully",200)}catch(e){return console.error("Error updating property:",e),(0,u.H)("Failed to update property",500)}}let d=new n.AppRouteRouteModule({definition:{kind:s.RouteKind.APP_ROUTE,page:"/api/admin/properties/[id]/route",pathname:"/api/admin/properties/[id]",filename:"route",bundlePath:"app/api/admin/properties/[id]/route"},resolvedPagePath:"/home/project/airbnb-clone/src/app/api/admin/properties/[id]/route.ts",nextConfigOutput:"",userland:o}),{workAsyncStorage:l,workUnitAsyncStorage:h,serverHooks:f}=d;function g(){return(0,i.patchFetch)({workAsyncStorage:l,workUnitAsyncStorage:h})}},28354:e=>{"use strict";e.exports=require("util")},29294:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-async-storage.external.js")},42317:(e,r,t)=>{"use strict";t.d(r,{BE:()=>u,Er:()=>a,HU:()=>c,V2:()=>f,aP:()=>l,nr:()=>p,pE:()=>h,rL:()=>d});var o=t(85663),n=t(43205),s=t.n(n);let i=process.env.JWT_SECRET||"fallback-secret-key";async function a(e){return o.Ay.hash(e,12)}async function u(e,r){return o.Ay.compare(e,r)}function c(e){return s().sign({userId:e.id,email:e.email,role:e.role},i,{expiresIn:"7d"})}function p(e){try{let r=s().verify(e,i);return{userId:r.userId,email:r.email,role:r.role}}catch(e){return console.error("JWT verification failed:",e),null}}function d(e){let r=e.headers.get("authorization");return r&&r.startsWith("Bearer ")?p(r.substring(7)):null}function l(){let e="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789",r="";for(let t=0;t<32;t++)r+=e.charAt(Math.floor(Math.random()*e.length));return r}function h(){let e=new Date;return e.setHours(e.getHours()+1),e}function f(e){return!!e&&new Date<new Date(e)}process.env.JWT_SECRET||console.warn("JWT_SECRET environment variable is not set, using fallback")},44870:e=>{"use strict";e.exports=require("next/dist/compiled/next-server/app-route.runtime.prod.js")},55511:e=>{"use strict";e.exports=require("crypto")},63033:e=>{"use strict";e.exports=require("next/dist/server/app-render/work-unit-async-storage.external.js")},78335:()=>{},79428:e=>{"use strict";e.exports=require("buffer")},96487:()=>{}};var r=require("../../../../../webpack-runtime.js");r.C(e);var t=e=>r(r.s=e),o=r.X(0,[719,475,26],()=>t(27989));module.exports=o})();